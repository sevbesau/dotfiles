---
name: Language request
about: Request for a new language to be supported
title: ''
labels: enhancement, good first issue, help wanted
assignees: ''

---

**Language information**

Please paste any useful information here !
