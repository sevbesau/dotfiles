const X: [i32; 2] = [
    1,
    2,
];

fn foo() {
    let _x = [
        1,
        2,
    ];
}
