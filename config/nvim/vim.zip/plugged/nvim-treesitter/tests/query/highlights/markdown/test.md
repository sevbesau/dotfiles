# H1
<!-- <- TSPunctSpecial -->

## H2
<!-- <- TSPunctSpecial -->

- Item 1
- Item 2
<!-- <- TSPunctSpecial -->

1. Item 1
2. Item 2
<!-- <- TSPunctSpecial -->

----![image_description](https://example.com/image.jpg "awesome image title")
<!--  ^ TSTextReference                                                   -->
<!--                              ^ TSURI                                 -->
<!--                                                          ^ TSLiteral -->
<!--^ TSPunctDelimiter                                                    -->
<!-- ^ TSPunctDelimiter                                                   -->
<!--                                                                      //TODO: currently disabled TSPunctDelimiter -->

[link_text](#local_reference "link go brr...")
<!-- ^ TSTextReference                                                    --> 
<!--                 ^ TSURI                                              -->
<!--                            ^ TSLiteral                               -->
<!-- <- TSPunctDelimiter                                                  -->
<!--                                         //TODO: currently disabled TSPunctDelimiter           -->
