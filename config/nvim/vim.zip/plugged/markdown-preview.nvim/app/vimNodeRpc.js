exports.run = function () {
  require('./lib/vim-node-rpc/lib')
}
